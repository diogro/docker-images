library(testthat)
library(evolqg)
test_package("evolqg")
